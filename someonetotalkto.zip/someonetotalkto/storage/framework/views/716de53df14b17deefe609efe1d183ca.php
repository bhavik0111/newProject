<!DOCTYPE html>
<html lang="fr">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="shortcut icon" href="images/favicon.png">
      <title>Someone to talk to</title>
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/swiper-bundle.min.css" rel="stylesheet">
      <link href="css/cssmenu-styles.css" rel="stylesheet">
      <link href="css/fontawesome.css" rel="stylesheet">
      <link href="css/style.css" rel="stylesheet">
      <link href="css/responsive.css" rel="stylesheet">
   </head>
   <body>
      <div class="menu-overlay"></div>
      <header class="hedcontainer">
         <div class="headerbg darkbluebg">
            <div class="container flex-ac-jb">
               <div class="top-contact-link flex-ac-jc flex-wrap">
                  <a href="tel:+447939895686"><img src="images/call-icon.svg" alt=""> <span>+44 7939 895 686</span></a>
                  <a href="mailto:info@someonetotalkto.online"><img src="images/email-icon.svg" alt=""> <span>info@someonetotalkto.online</span></a>
               </div>
               <div class="topcontlanguage">
                  <ul class="flex-ac-jc">
                     <li><a href=""><i class="fa fa-facebook"></i></a></li>
                     <li><a href=""><i class="fa fa-twitter"></i></a></li>
                     <li><a href=""><i class="fa fa-instagram"></i></a></li>
                     <li><a href=""><i class="fa fa-youtube-play"></i></a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="header-sec navesticky sticky">
            <div class="container">
               <div class="header-bar flex-ac-jb">
                  <div class="hedlogo"><a href="index.html"><img src="images/logo.png" alt="" /></a> </div>
                  <div class="head-btn flex-ac-jb">
                     <div class="header-nav-bar order-2 order-xl-1">
                        <div id="cssmenu">
                           <ul>
                              <li class="active"><a href="index.html">Home</a></li>
                              <li>
                                 <a href="find-professional.html">Find a Professional?</a>
                                 <ul>
                                    <li><a href="find-professional.html">Find a Professional?</a></li>
                                    <li><a href="find-professional.html">Find a Professional?</a></li>
                                 </ul>
                              </li>
                              <li><a href="what-worrying-you.html">What's Worrying you?</a></li>
                              <li><a href="aboutus.html">About Us</a></li>
                              <li><a href="contact-us.html">Contact Us</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="header-btn-link order-1 order-xl-2">
                        <a href="join-professional-partner.html" class="btn btn-darkbluebg">Join as Professional Partner</a>
                        <a href="join-user.html" class="btn btn-greenbg">Join as User</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <div class="homemanibanner">
         <div class="swiper homemainslider">
            <div class="swiper-wrapper">
               <div class="swiper-slide homebannerimg">
                  <div class="texturebg" style="background-image:url(images/home-frame-bg.png);"></div>
                  <div class="banner-main-img"><img src="images/banner-img-1.jpg" alt=""></div>
                  <div class="container">
                     <div class="banner-content-sec">
                        <h5>A CENTRALIZED HUB OF</h5>
                        <h1>Art Therapist</h1>
                        <div class="banner-cont-text">To ensure you can find <span>SOMEONE TO TALK TO</span></div>
                        <a href="" class="btn btn-darkbluebg">Know More</a>
                     </div>
                  </div>
               </div>
               <div class="swiper-slide homebannerimg">
                  <div class="texturebg" style="background-image:url(images/home-frame-bg.png);"></div>
                  <div class="banner-main-img"><img src="images/banner-img-2.jpg" alt=""></div>
                  <div class="container">
                     <div class="banner-content-sec">
                        <h5>A CENTRALIZED HUB OF</h5>
                        <h1>BACP Qualified <br>Therapist</h1>
                        <div class="banner-cont-text">To ensure you can find <span>SOMEONE TO TALK TO</span></div>
                        <a href="" class="btn btn-darkbluebg">Know More</a>
                     </div>
                  </div>
               </div>
               <div class="swiper-slide homebannerimg">
                  <div class="texturebg" style="background-image:url(images/home-frame-bg.png);"></div>
                  <div class="banner-main-img"><img src="images/banner-img-3.jpg" alt=""></div>
                  <div class="container">
                     <div class="banner-content-sec">
                        <h5>A CENTRALIZED HUB OF</h5>
                        <h1>Counsellor</h1>
                        <div class="banner-cont-text">To ensure you can find <span>SOMEONE TO TALK TO</span></div>
                        <a href="" class="btn btn-darkbluebg">Know More</a>
                     </div>
                  </div>
               </div>
            </div>
            <div class="main-slider-arrow">
               <div class="container position-relative">
                  <div class="swiper-button-next"></div>
                  <div class="swiper-button-prev"></div>
               </div>
            </div>
         </div>
      </div>
      <div class="we-are-helping-sec lightgraybg common-PTB">
         <div class="container">
            <h2 class="text-center">We are helping for</h2>
            <div class="row loadmore-col">
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #84851d;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Abortion</div>
                        </div>
                        <div class="flip-back-detail" style="background-color: #84851d;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Abortion</h5>
                              <div class="profession-flip-detail">An abortion is a procedure to end a pregnancy.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #034801;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Abuse</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #034801;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Abuse</h5>
                              <div class="profession-flip-detail">The word abuse covers many different ways someone may harm a vulnerable adult.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #652f58;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Addiction</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #652f58;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Addiction</h5>
                              <div class="profession-flip-detail">An addiction is a chronic dysfunction of the brain system that involves reward, motivation, and memory.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #cc0000;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Affairs and betrayals</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #cc0000;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Affairs and betrayals</h5>
                              <div class="profession-flip-detail">If someone close to you has ever broken your trust, you probably felt the sting of betrayal. This pain can leave deep wounds.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #00695b;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Anger Management</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #00695b;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Anger Management</h5>
                              <div class="profession-flip-detail">Anger Management refers to a process. It can help people identify stressors. People can learn steps to help them stay calm in anger management. </div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #bc00b5;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Anxiety</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #bc00b5;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Anxiety</h5>
                              <div class="profession-flip-detail">Anxiety is a normal emotion, it's our brain's way of reacting to stress and alerting us when we are in danger.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #563c00;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Asperger's Syndrome</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #563c00;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Asperger's Syndrome</h5>
                              <div class="profession-flip-detail">Many people who fit the profile for Asperger syndrome are now being diagnosed with Autistic Spectrum Disorder instead.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #393e81;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Attachment Disorder</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #393e81;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Attachment Disorder</h5>
                              <div class="profession-flip-detail">Attachment disorders are conditions that can develop in young children who have issues establishing a deep emotional connection—known as the attachment bond—with their parent or primary caregiver.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #950d77;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Attention Deficit Hyperactivity Disorder (ADHD)</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #950d77;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Attention Deficit Hyperactivity Disorder (ADHD)</h5>
                              <div class="profession-flip-detail">Attention Deficit Hyperactivity Disorder (ADHD) is a childhood-onset neurodevelopmental disorder that interferes with functioning through a persistent pattern of inattention and/or hyperactivity-impulsivity.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #0ca81e;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Autism Spectrum Disorder (ASD)</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #0ca81e;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Autism Spectrum Disorder (ASD)</h5>
                              <div class="profession-flip-detail">Autism Spectrum Disorder is a lifelong developmental disorder which affects an individual's ability to socialize and communicate, have restrictive interests and repetitive behaviours.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #c0c200;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Bereavement</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #c0c200;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Bereavement</h5>
                              <div class="profession-flip-detail">Hearing the news of a sudden bereavement can be a traumatic and devastating event in itself and can affect people in different ways.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #843dba;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Bipolar Disorder</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #843dba;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Bipolar Disorder</h5>
                              <div class="profession-flip-detail">Bipolar Disorder is a group of brain disorders that can cause extreme fluctuation in a person's mood, energy and ability to function.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #eab000;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Borderline Personality Disorder (BPD)</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #eab000;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Borderline Personality Disorder (BPD)</h5>
                              <div class="profession-flip-detail">Borderline Personality Disorder (BPD) is a personality disorder that is characterised by a pattern of emotional instability and unstable relationships with other people.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #43bbb7;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Bullying</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #43bbb7;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Bullying</h5>
                              <div class="profession-flip-detail">All bullying is unacceptable and should not be tolerated. It can affect anyone, and all people are all potential targets – either as an adult, child, at work, at school, within the community, at home, or online.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-6 col-md-4 col-lg-3 col-xl-3">
                  <div class="helping-col">
                     <div class="we-helping-flip-inner">
                        <div class="whitebg">
                           <div class="helping-icon" style="background-color: #bdbb7a;"><img src="images/help-list-icon-1.png" alt=""></div>
                           <div class="helping-title">Cancer</div>
                        </div>
                        <div class="flip-back-detail"  style="background-color: #bdbb7a;">
                           <a href="what-worrying-you-detail.html">
                              <h5>Cancer</h5>
                              <div class="profession-flip-detail">Many people will be affected by cancer in their life. Cancer Research UK estimates that one in two people in the UK born after 1960 will be diagnosed with some form of cancer during their lifetime.</div>
                              <div class="helping-readmore">Read More...</div>
                           </a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- <div class="showmore-btn text-center"><a href="" class="btn btn-darkbluebg">Show more</a></div> -->
         </div>
      </div>
      <div class="profession-sec text-center common-PTB6030">
         <div class="container">
            <h2>Professional Partner</h2>
            <div class="profession-sm-cont">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor<br>
               incididunt ut labore et dolore magna aliqua.
            </div>
            <div class="row">
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/art-therapist-icon.png" alt=""></div>
                        <div class="profession-pro-title">Art Therapist</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/bacp-qualified-therapist.png" alt=""></div>
                        <div class="profession-pro-title">Qualified Therapist</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/counsellor.png" alt=""></div>
                        <div class="profession-pro-title">Counsellor</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/dance-therapist.png" alt=""></div>
                        <div class="profession-pro-title">Dance Therapist</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/life-coach.png" alt=""></div>
                        <div class="profession-pro-title">Life Coach</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/mentor.png" alt=""></div>
                        <div class="profession-pro-title">Mentor</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/personal-trainer.png" alt=""></div>
                        <div class="profession-pro-title">Personal Trainer</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/psychiatrists.png" alt=""></div>
                        <div class="profession-pro-title">Psychiatrists</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/psychologists.png" alt=""></div>
                        <div class="profession-pro-title">Psychologists</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/spiritual-teacher.png" alt=""></div>
                        <div class="profession-pro-title">Spiritual Teacher</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/wellness-coach.png" alt=""></div>
                        <div class="profession-pro-title">Wellness Coach</div>
                     </a>
                  </div>
               </div>
               <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
                  <div class="profession-box">
                     <a href="">
                        <div class="profession-icon"><img src="images/yoga-teacher.png" alt=""></div>
                        <div class="profession-pro-title">Yoga Teacher</div>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="articleblog-sec text-center common-PTB6030" style="background-image:url(images/article-main-img.jpg);">
         <div class="container position-relative">
            <h2>Counselling articles</h2>
            <div class="profession-sm-cont">Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor<br>
               incididunt ut labore et dolore magna aliqua.
            </div>
            <div class="row">
               <div class="col-lg-4">
                  <div class="articleblog-box">
                     <div class="article-img">
                        <a href=""><img src="images/articles-img-1.jpg" alt=""></a>
                     </div>
                     <div class="article-cont">
                        <div class="tag-date">13th <span>May</span></div>
                        <h4><a href="">How To Take A Short Break From The Social Media</a></h4>
                        <a href="" class="btn btn-darkbluebg">Read More</a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="articleblog-box">
                     <div class="article-img">
                        <a href=""><img src="images/articles-img-2.jpg" alt=""></a>
                     </div>
                     <div class="article-cont">
                        <div class="tag-date">14th <span>May</span></div>
                        <h4><a href="">Lorem ipsum dolor sit amet consectetur adipiscing</a></h4>
                        <a href="" class="btn btn-darkbluebg">Read More</a>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4">
                  <div class="articleblog-box">
                     <div class="article-img">
                        <a href=""><img src="images/articles-img-3.jpg" alt=""></a>
                     </div>
                     <div class="article-cont">
                        <div class="tag-date">14th <span>May</span></div>
                        <h4><a href="">How Does A Psychologist Help To Maintain A Good Mental Health</a></h4>
                        <a href="" class="btn btn-darkbluebg">Read More</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="testimonial-sec common-PTB" style="background-image:url(images/story-bg-img.png);">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-lg-6">
                  <div class="success-img">
                     <img src="images/success-stories-main-img.jpg" alt="">
                  </div>
               </div>
               <div class="col-lg-6">
                  <div class="stories-sec">
                     <h2>Success stories</h2>
                     <div class="testimonial-thumb-slider">
                        <div class="swiper testimonial-slider2">
                           <div class="swiper-wrapper">
                              <div class="swiper-slide">
                                 <div class="testimonial-box">
                                    <div class="testimonial-cont">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                       eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                       Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                       laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                                       dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                       fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
                                    </div>
                                    <h3>Sarah Hanna</h3>
                                    <h6>Officer</h6>
                                 </div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="testimonial-box">
                                    <div class="testimonial-cont">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                       eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                       Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                       laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                                       dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                       fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
                                    </div>
                                    <h3>Sarah Hanna</h3>
                                    <h6>Officer</h6>
                                 </div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="testimonial-box">
                                    <div class="testimonial-cont">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                       eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                       Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                       laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                                       dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                       fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
                                    </div>
                                    <h3>Sarah Hanna</h3>
                                    <h6>Officer</h6>
                                 </div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="testimonial-box">
                                    <div class="testimonial-cont">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                       eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                       Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                       laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                                       dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                       fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
                                    </div>
                                    <h3>Sarah Hanna</h3>
                                    <h6>Officer</h6>
                                 </div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="testimonial-box">
                                    <div class="testimonial-cont">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                                       eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                       Ut enim ad minim veniam, quis nostrud exercitation ullamco
                                       laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure
                                       dolor in reprehenderit in voluptate velit esse cillum dolore eu
                                       fugiat nulla pariatur. Excepteur sint occaecat cupidatat.
                                    </div>
                                    <h3>Sarah Hanna</h3>
                                    <h6>Officer</h6>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div thumbsSlider="" class="swiper testimonial-slider">
                           <div class="swiper-wrapper">
                              <div class="swiper-slide">
                                 <div class="thumb-slider-img"><img src="images/author-img-1.jpg" alt=""></div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="thumb-slider-img"><img src="images/author-img-2.jpg" alt=""></div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="thumb-slider-img"><img src="images/author-img-3.jpg" alt=""></div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="thumb-slider-img"><img src="images/author-img-4.jpg" alt=""></div>
                              </div>
                              <div class="swiper-slide">
                                 <div class="thumb-slider-img"><img src="images/author-img-5.jpg" alt=""></div>
                              </div>
                           </div>
                           <div class="swiper-button-next"></div>
                           <div class="swiper-button-prev"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <footer>
         <div class="ft-bg" style="background-image: url(images/footer-bg-img.jpg);">
            <div class="container position-relative">
               <div class="row">
                  <div class="col-md-12 col-lg-4">
                     <div class="ft-logo mb-4">
                        <a href="index.html"><img src="images/footer-logo.png" alt=""></a>
                     </div>
                     <div class="ft-about-cont">
                        A CENTRALIZED HUB OF PERSONAL TRAINERS, WELLNESS COACHES, LIFE COACHES, MENTORS, ART THERAPISTS, DANCE THERAPISTS, COUNSELLORS, QUALIFIED THERAPISTS, YOGA TEACHERS AND DOCTORS PLUS MANY OTHERS TO ENSURE YOU CAN FIND SOMEONE TO TALK TO...
                     </div>
                  </div>
                  <div class="col-md-6 col-lg-4">
                     <div class="ft-navbar ft-pl">
                        <h3>Quick Links</h3>
                        <ul>
                           <li><a href="index.html">Home</a></li>
                           <li><a href="find-professional.html">Find a Professional?</a></li>
                           <li><a href="what-worrying-you.html">What's Worrying you?</a></li>
                           <li><a href="service.html">Services</a></li>
                           <li><a href="aboutus.html">About Us</a></li>
                           <li><a href="contact-us.html">Contact Us</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-6 col-lg-4">
                     <div class="ft-pl">
                        <h3>Contact Us</h3>
                        <div class="ft-contact">
                           <div class="d-flex mb-3">
                              <div class="ft-add-icon"><img src="images/call-icon.svg" alt=""></div>
                              <div class="ft-cont-det">
                                 <h5>Phone No:</h5>
                                 <p><a href="tel:+447939895686">+44 7939 895 686</a></p>
                              </div>
                           </div>
                           <div class="d-flex mb-3">
                              <div class="ft-add-icon"><img src="images/email-icon.svg" alt=""></div>
                              <div class="ft-cont-det">
                                 <h5>Email Address:</h5>
                                 <p><a href="mailto:info@someonetotalkto.online">info@someonetotalkto.online</a></p>
                              </div>
                           </div>
                        </div>
                        <div class="ft-social pt-2">
                           <ul class="d-flex">
                              <li><a href=""><i class="fa fa-facebook"></i></a></li>
                              <li><a href=""><i class="fa fa-twitter"></i></a></li>
                              <li><a href=""><i class="fa fa-instagram"></i></a></li>
                              <li><a href=""><i class="fa fa-youtube-play"></i></a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="copyright-bg text-center py-4">
            <div class="container">
               &copy; Someone to talk to 2019-2023. All rights reserved.
            </div>
         </div>
      </footer>
      <script src="js/jquery-3.6.1.js"></script>
      <script src="js/bootstrap.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/cssmenu-script.js"></script>
      <script src="js/swiper-bundle.min.js"></script>
      <script src="js/sticky-header.js"></script>
      <script src="js/btnloadmore.js"></script>
      <script src="js/main.js"></script>
      <script>
         var swiper = new Swiper(".homemainslider", {
           loop: true,
           speed: 1200,
           effect:"fade",
           autoplay: {
             delay: 3000,
             disableOnInteraction: false,
            },
           navigation: {
             nextEl: ".swiper-button-next",
             prevEl: ".swiper-button-prev",
           },
         });
      </script>
      <script>
         var testimonialslider = new Swiper(".testimonial-slider", {
           spaceBetween: 10,
           slidesPerView: 5,
           grabCursor: true,
           freeMode: true,
           watchSlidesProgress: true,
           navigation: {
             nextEl: ".swiper-button-next",
             prevEl: ".swiper-button-prev",
           },
           breakpoints: {
               320: {
                  slidesPerView: 3,

               },
               768: {
                  slidesPerView: 5,

               },
               992: {
                  slidesPerView: 4,

               },
               1200: {
                  slidesPerView: 5,

               },
            },
         });
         var testimonialslider2 = new Swiper(".testimonial-slider2", {
           spaceBetween: 10,
           grabCursor: true,
           thumbs: {
             swiper: testimonialslider,
           },
         });
      </script>
      <script>
         $(document).ready( function() {
            $('.loadmore-col').btnLoadmore({
               showItem : 15,
               whenClickBtn : 5,
               textBtn : 'Show more',
               classBtn : 'btn btn-darkbluebg'
            });
         });

      </script>
   </body>
</html>
<?php /**PATH C:\xampp\htdocs\someonetotalkto\resources\views/welcome.blade.php ENDPATH**/ ?>