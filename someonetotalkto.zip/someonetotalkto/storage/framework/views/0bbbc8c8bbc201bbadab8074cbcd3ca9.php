<div class="sidebar-header">
    <div class="d-flex justify-content-between">
        <div class="logo">
            <a href="index.html"><img src="assets/images/logo/logo.png" alt="Logo"
                    srcset=""></a>
        </div>
        <div class="toggler">
            <a href="#" class="sidebar-hide d-xl-none d-block"><i
                    class="bi bi-x bi-middle"></i></a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\someonetotalkto\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>